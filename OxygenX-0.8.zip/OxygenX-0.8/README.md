# OxygenX

```
Features:

Multi-threading
Proxy and Proxyless
HTTPS, SOCKS4, SOCKS5 Proxies supported (and it also auto auth proxies with username and password)
Gets proxies from api link and refreshes link.
Checks capes for Minecon, Optifine, Labymod, and LiquidBounce
Checks ranks for Hypixel, Mineplex, Hive, Velt
Saves Levels for Hypixel and Mineplex and also gets Hypixel's last logout date.
Checks for Email Access
```

You can download the exe version in releases

# Support:
If you need any help come on to https://discord.gg/gAgCaX8 and I will do my best to support.

Please do not ask me about cracking.

# Donate
Paypal: https://bit.ly/3eZ4xx9

You can also support me by tipping me with BAT or starting using Brave https://brave.com/rtx014

# Terms and conditions
This repository is for educational purposes only.

I am not responsible for any actions for anyone who use this program.
